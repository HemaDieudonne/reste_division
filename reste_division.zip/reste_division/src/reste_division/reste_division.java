/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reste_division;

import static java.lang.Math.floor;
import java.util.Scanner;

/**
 *
 * @author TRAORE
 */
public class reste_division {
    public reste_division(){
}

    public static void main(String[] args) {
   new reste_division().Model(); // appel de la fonction Model
    }
    
    // CREATION DE LA FONCTION MODEL PERMETTANT DE SAISIR DEUX NOMBRES ET AFFICHER 
    // LE RESULTAT DE LEUR DIVISION ENTIERE
    public void Model()
    {
        Saisie saisie = new Saisie(); // Instanciation de la classe saisie pour le control des valeurs entrées
                                      
       // Declaration des variables
       int  nb2,nb1,rest; // Declaration des variables
        
        System.out.println("ENTRER NOMBRE 1: ");
        nb1 = saisie.getSaisieInt();
        System.out.println("ENTRER NOMBRE 2: ");
         nb2 =saisie.getSaisieInt();
 
        rest=nb1%nb2; // Affectation du reste de la division à rest

            System.out.println("LE RESTE DE LA DIVISION ENTIERE EST :"+rest);

    }
}
