package reste_division;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Alino-91
 */
public class Saisie {
 
    // creation d'un constructeur
    public Saisie() {
    }//fin constructeur

    public synchronized int getSaisieInt() {
        int x = 0;
        boolean boolErreur = false;
        do {
            if (boolErreur) {
                System.out.println("Erreur : veuillez saisir un entier s.v.p !!!");
            }
            boolErreur = false;
            Scanner sc = new Scanner(System.in);
            //System.out.println("Question ?");
            try {
                x = sc.nextInt();
            } catch (InputMismatchException e) {
                //e.printStackTrace();
                boolErreur = true;
            }
        } while (boolErreur);
        return x;
    }

    /*****************  LES AUTRES FOCTIONS EN DESSOUS SONT UTILES POUR LE CAS DES REEL,CHAINE DE CARACTERE...........  ******************/
    
    /*
    
    public synchronized double getSaisieDouble() {
        double x = 0.0;
        boolean boolErreur = false;
        do {
            if (boolErreur) {
                System.out.println("Erreur : veuillez saisir un réel s.v.p !!!");
            }
            boolErreur = false;
            Scanner sc = new Scanner(System.in);
            try {
                x = sc.nextDouble();
            } catch (InputMismatchException e) {
                boolErreur = true;
            }
        } while (boolErreur);
        return (double) x;
    }

    public synchronized float getSaisieFloat() {
        float x = (float) 0.0;
        boolean boolErreur = false;
        do {
            if (boolErreur) {
                System.out.println("Erreur : veuillez saisir un réel s.v.p !!!");
            }
            boolErreur = false;
            Scanner sc = new Scanner(System.in);
            try {
                x = sc.nextFloat();
            } catch (InputMismatchException e) {
                boolErreur = true;
            }
        } while (boolErreur);
        return (float) x;
    }

    public synchronized String getSaisieString() {
        String s = new Scanner(System.in).next();
        return s.trim();
    }

    public synchronized char getSaisieCaractere() {
        String s = "";
        boolean boolErreur = false;
        do {
            if (boolErreur) {
                System.out.println("Erreur : veuillez saisir un seul et unique caractère s.v.p !!!");
            }
            boolErreur = false;
            s = new Scanner(System.in).next();
            if(s.length() != 1) {
                boolErreur = true;
            }
        } while (boolErreur);
        return s.charAt(0);
    }
*/
}//fin class

